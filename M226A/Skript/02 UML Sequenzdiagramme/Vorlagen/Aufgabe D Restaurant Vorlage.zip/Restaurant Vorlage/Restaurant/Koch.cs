using System;
using System.Collections.Generic;
using System.Text;

namespace Restaurant
{
    public class Koch
    {
        //Membervariablen
        //Konstruktoren
        //Methoden
    }
}
