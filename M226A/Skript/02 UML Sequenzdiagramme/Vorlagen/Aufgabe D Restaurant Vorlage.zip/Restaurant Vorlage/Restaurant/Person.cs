using System;
using System.Collections.Generic;
using System.Text;

namespace Restaurant
{
    public class Person
    {
        //Membervariablen
        //Konstruktoren
        //Methoden
    }
}
