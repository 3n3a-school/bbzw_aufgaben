using System;
using System.Collections.Generic;
using System.Text;

namespace Restaurant
{
    class Program
    {
        static void Main(string[] args)
        {
            Koch k1 = new Koch(12, "Oliver");
            k1.setVorname("Jamie");
            k1.setSterne(3);
            Koch k2 = new Koch(15, "M�lzer", "Tim");
            k2.setSterne(3);

            Gast g1 = new Gast();
            g1.setName("Bucher");
            g1.setVorname("Roland");

            Gast g2 = new Gast("Brunner", "Peter");

            Restaurant r = new Restaurant("BBZS Kantine");
            r.Hinzufuegen(k1);
            r.Hinzufuegen(k2);
            r.Hinzufuegen(g1);
            r.Hinzufuegen(g2);

            r.Ausgabe();

        }
    }
}
