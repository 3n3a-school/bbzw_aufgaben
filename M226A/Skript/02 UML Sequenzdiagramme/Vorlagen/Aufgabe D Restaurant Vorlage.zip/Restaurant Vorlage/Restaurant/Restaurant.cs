using System;
using System.Collections.Generic;
using System.Text;

namespace Restaurant
{
    public class Restaurant
    {
        //Membervariablen
        //Konstruktoren
        //Methoden
    }
}
