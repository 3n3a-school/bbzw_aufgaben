﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZylinderApp {
    public class Zylinder {
        //Membervariablen
        private Kreis m_Grundflaeche;
        private double m_Hoehe;
        //Konstruktoren
        public Zylinder(double d, double h) {
            m_Grundflaeche = new Kreis(d);
            setHoehe(h);
        }
        //Methoden
        public double getVolumen() {
            return m_Grundflaeche.getFlaeche() * getHoehe();
        }
        public double getOberflaeche() {
            return 2 * m_Grundflaeche.getFlaeche() + getHoehe() * m_Grundflaeche.getUmfang();
        }
        private void setHoehe(double h) { m_Hoehe = h; }
        public double getHoehe() { return m_Hoehe; }

    }
}
