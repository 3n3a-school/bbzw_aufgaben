﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZylinderApp {
    public class Kreis {
        //Membervariablen
        private double m_durchmesser;
        //Konstruktoren
        public Kreis(double d) {
            setDurchmesser(d);
        }
        //Methoden
        public void setDurchmesser(double d) {
            m_durchmesser = d;
        }
        protected double getDurchmesser() {
            return m_durchmesser;
        }
        public double getFlaeche() {
            return m_durchmesser * m_durchmesser * Math.PI / 4;
        }
        public double getUmfang() {
            return m_durchmesser * Math.PI;
        }
        public static double CalculateFlaeche(double d) {
            return d * d * Math.PI / 4;
        }

    }
}
