﻿namespace Quader
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblSeiteA = new System.Windows.Forms.Label();
            this.txtSeiteA = new System.Windows.Forms.TextBox();
            this.txtSeiteB = new System.Windows.Forms.TextBox();
            this.lblSeiteB = new System.Windows.Forms.Label();
            this.txtSeiteC = new System.Windows.Forms.TextBox();
            this.lblSeiteC = new System.Windows.Forms.Label();
            this.cmdBerechnen = new System.Windows.Forms.Button();
            this.txtSeiteE = new System.Windows.Forms.TextBox();
            this.lblSeiteE = new System.Windows.Forms.Label();
            this.txtOberflaeche = new System.Windows.Forms.TextBox();
            this.lblOberflaeche = new System.Windows.Forms.Label();
            this.txtVolumen = new System.Windows.Forms.TextBox();
            this.lblVolumen = new System.Windows.Forms.Label();
            this.txtSeiteF = new System.Windows.Forms.TextBox();
            this.lblSeiteF = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(172, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(238, 181);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lblSeiteA
            // 
            this.lblSeiteA.AutoSize = true;
            this.lblSeiteA.Location = new System.Drawing.Point(37, 12);
            this.lblSeiteA.Name = "lblSeiteA";
            this.lblSeiteA.Size = new System.Drawing.Size(43, 13);
            this.lblSeiteA.TabIndex = 1;
            this.lblSeiteA.Text = "Seite a:";
            // 
            // txtSeiteA
            // 
            this.txtSeiteA.Location = new System.Drawing.Point(86, 9);
            this.txtSeiteA.Name = "txtSeiteA";
            this.txtSeiteA.Size = new System.Drawing.Size(71, 20);
            this.txtSeiteA.TabIndex = 2;
            // 
            // txtSeiteB
            // 
            this.txtSeiteB.Location = new System.Drawing.Point(86, 33);
            this.txtSeiteB.Name = "txtSeiteB";
            this.txtSeiteB.Size = new System.Drawing.Size(71, 20);
            this.txtSeiteB.TabIndex = 4;
            // 
            // lblSeiteB
            // 
            this.lblSeiteB.AutoSize = true;
            this.lblSeiteB.Location = new System.Drawing.Point(37, 36);
            this.lblSeiteB.Name = "lblSeiteB";
            this.lblSeiteB.Size = new System.Drawing.Size(43, 13);
            this.lblSeiteB.TabIndex = 3;
            this.lblSeiteB.Text = "Seite b:";
            // 
            // txtSeiteC
            // 
            this.txtSeiteC.Location = new System.Drawing.Point(86, 57);
            this.txtSeiteC.Name = "txtSeiteC";
            this.txtSeiteC.Size = new System.Drawing.Size(71, 20);
            this.txtSeiteC.TabIndex = 6;
            // 
            // lblSeiteC
            // 
            this.lblSeiteC.AutoSize = true;
            this.lblSeiteC.Location = new System.Drawing.Point(37, 60);
            this.lblSeiteC.Name = "lblSeiteC";
            this.lblSeiteC.Size = new System.Drawing.Size(43, 13);
            this.lblSeiteC.TabIndex = 5;
            this.lblSeiteC.Text = "Seite c:";
            // 
            // cmdBerechnen
            // 
            this.cmdBerechnen.Location = new System.Drawing.Point(12, 81);
            this.cmdBerechnen.Name = "cmdBerechnen";
            this.cmdBerechnen.Size = new System.Drawing.Size(145, 23);
            this.cmdBerechnen.TabIndex = 7;
            this.cmdBerechnen.Text = "Berechnen";
            this.cmdBerechnen.UseVisualStyleBackColor = true;
            this.cmdBerechnen.Click += new System.EventHandler(this.cmdBerechnen_Click);
            // 
            // txtSeiteE
            // 
            this.txtSeiteE.Location = new System.Drawing.Point(86, 132);
            this.txtSeiteE.Name = "txtSeiteE";
            this.txtSeiteE.ReadOnly = true;
            this.txtSeiteE.Size = new System.Drawing.Size(71, 20);
            this.txtSeiteE.TabIndex = 9;
            // 
            // lblSeiteE
            // 
            this.lblSeiteE.AutoSize = true;
            this.lblSeiteE.Location = new System.Drawing.Point(37, 139);
            this.lblSeiteE.Name = "lblSeiteE";
            this.lblSeiteE.Size = new System.Drawing.Size(43, 13);
            this.lblSeiteE.TabIndex = 8;
            this.lblSeiteE.Text = "Seite e:";
            // 
            // txtOberflaeche
            // 
            this.txtOberflaeche.Location = new System.Drawing.Point(86, 156);
            this.txtOberflaeche.Name = "txtOberflaeche";
            this.txtOberflaeche.ReadOnly = true;
            this.txtOberflaeche.Size = new System.Drawing.Size(71, 20);
            this.txtOberflaeche.TabIndex = 11;
            // 
            // lblOberflaeche
            // 
            this.lblOberflaeche.AutoSize = true;
            this.lblOberflaeche.Location = new System.Drawing.Point(12, 163);
            this.lblOberflaeche.Name = "lblOberflaeche";
            this.lblOberflaeche.Size = new System.Drawing.Size(68, 13);
            this.lblOberflaeche.TabIndex = 10;
            this.lblOberflaeche.Text = "Oberflaeche:";
            // 
            // txtVolumen
            // 
            this.txtVolumen.Location = new System.Drawing.Point(86, 180);
            this.txtVolumen.Name = "txtVolumen";
            this.txtVolumen.ReadOnly = true;
            this.txtVolumen.Size = new System.Drawing.Size(71, 20);
            this.txtVolumen.TabIndex = 13;
            // 
            // lblVolumen
            // 
            this.lblVolumen.AutoSize = true;
            this.lblVolumen.Location = new System.Drawing.Point(29, 189);
            this.lblVolumen.Name = "lblVolumen";
            this.lblVolumen.Size = new System.Drawing.Size(51, 13);
            this.lblVolumen.TabIndex = 12;
            this.lblVolumen.Text = "Volumen:";
            // 
            // txtSeiteF
            // 
            this.txtSeiteF.Location = new System.Drawing.Point(86, 108);
            this.txtSeiteF.Name = "txtSeiteF";
            this.txtSeiteF.ReadOnly = true;
            this.txtSeiteF.Size = new System.Drawing.Size(71, 20);
            this.txtSeiteF.TabIndex = 15;
            // 
            // lblSeiteF
            // 
            this.lblSeiteF.AutoSize = true;
            this.lblSeiteF.Location = new System.Drawing.Point(37, 111);
            this.lblSeiteF.Name = "lblSeiteF";
            this.lblSeiteF.Size = new System.Drawing.Size(40, 13);
            this.lblSeiteF.TabIndex = 14;
            this.lblSeiteF.Text = "Seite f:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(433, 221);
            this.Controls.Add(this.txtSeiteF);
            this.Controls.Add(this.lblSeiteF);
            this.Controls.Add(this.txtVolumen);
            this.Controls.Add(this.lblVolumen);
            this.Controls.Add(this.txtOberflaeche);
            this.Controls.Add(this.lblOberflaeche);
            this.Controls.Add(this.txtSeiteE);
            this.Controls.Add(this.lblSeiteE);
            this.Controls.Add(this.cmdBerechnen);
            this.Controls.Add(this.txtSeiteC);
            this.Controls.Add(this.lblSeiteC);
            this.Controls.Add(this.txtSeiteB);
            this.Controls.Add(this.lblSeiteB);
            this.Controls.Add(this.txtSeiteA);
            this.Controls.Add(this.lblSeiteA);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Quaderapplikation";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblSeiteA;
        private System.Windows.Forms.TextBox txtSeiteA;
        private System.Windows.Forms.TextBox txtSeiteB;
        private System.Windows.Forms.Label lblSeiteB;
        private System.Windows.Forms.TextBox txtSeiteC;
        private System.Windows.Forms.Label lblSeiteC;
        private System.Windows.Forms.Button cmdBerechnen;
        private System.Windows.Forms.TextBox txtSeiteE;
        private System.Windows.Forms.Label lblSeiteE;
        private System.Windows.Forms.TextBox txtOberflaeche;
        private System.Windows.Forms.Label lblOberflaeche;
        private System.Windows.Forms.TextBox txtVolumen;
        private System.Windows.Forms.Label lblVolumen;
        private System.Windows.Forms.TextBox txtSeiteF;
        private System.Windows.Forms.Label lblSeiteF;
    }
}

