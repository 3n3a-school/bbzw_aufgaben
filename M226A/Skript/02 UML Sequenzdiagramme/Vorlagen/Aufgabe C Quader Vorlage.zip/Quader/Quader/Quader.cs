﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Quader
{
    public class Quader
    {
        private Rechteck m_Grundflaeche = null;
        private double m_SeiteC;

        public Quader(double a, double b, double c) {
            m_Grundflaeche = new Rechteck(a, b);
            setSeiteC(c);
        }
        public double getSeiteC() {
            return m_SeiteC;
        }
        public void setSeiteC(double value) {
            m_SeiteC = value;
        }
        public double getDiagonaleF() {
            return m_Grundflaeche.getDiagonale();
        }
        public double getDiagonaleE() {
            double f = m_Grundflaeche.getDiagonale();
            return Math.Sqrt(Math.Pow(f, 2) + Math.Pow(m_SeiteC, 2));
        }
        public double getOberflaeche() {
            double dO = 2 * m_Grundflaeche.getFlaeche();
            dO += 2 * m_Grundflaeche.getSeiteA() * m_SeiteC;
            dO += 2 * m_Grundflaeche.getSeiteB() * m_SeiteC;
            return dO;
        }
        public double getVolumen() {
            return m_Grundflaeche.getFlaeche() * m_SeiteC;
        }
    }
}
