﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Quader
{
    public class Rechteck
    {
        private double m_SeiteA;
        private double m_SeiteB;

        public Rechteck() {
            setSeiteA(0.00);
            setSeiteB(0.00);
        }
        public Rechteck(double a, double b){
            setSeiteA(a);
            setSeiteB(b);
        }
        public double getSeiteA() {
            return m_SeiteA;
        }
        public void setSeiteA(double value) {
            m_SeiteA = value;
        }
        public double getSeiteB(){
            return m_SeiteB;
        }
        public void setSeiteB(double value){
            m_SeiteB = value;
        }
        public double getUmfang() {
            return 2 * (m_SeiteA + m_SeiteB);
        }
        public double getFlaeche() {
            return m_SeiteA * m_SeiteB;
        }
        public double getDiagonale() {
            return Math.Sqrt( Math.Pow(m_SeiteA,2) +Math.Pow(m_SeiteB,2));
        }
    }
}
