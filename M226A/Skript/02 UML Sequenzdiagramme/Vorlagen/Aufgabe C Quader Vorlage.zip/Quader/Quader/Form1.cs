﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Quader
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void cmdBerechnen_Click(object sender, EventArgs e)
        {
            double a = Convert.ToDouble(txtSeiteA.Text);
            double b= Convert.ToDouble(txtSeiteB.Text);
            double c = Convert.ToDouble(txtSeiteC.Text);
            Quader q = new Quader(a, b, c);
            txtSeiteF.Text = q.getDiagonaleF().ToString("0.##");
            txtSeiteE.Text = q.getDiagonaleE().ToString("0.##");
            txtOberflaeche.Text = q.getOberflaeche().ToString("0.##");
            txtVolumen.Text = q.getVolumen().ToString("0.##");
        }

    }
}
