﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AufgabeB {
    public class Program {
        static void Main(string[] args) {
            Boss b = new Boss();
            b.setName("Hugo");
            Angestellter a1 = new Angestellter("Peter");
            a1.setBoss(b);
            Angestellter a2 = new Angestellter("Claudia", b);
            Angestellter a3 = new Angestellter("Jürg");
            b.AddUnterstellt(a3);

        }
    }
}
