﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AufgabeB {
    public class Boss {
        //Membervariablen
        private string m_Name;
        private List<Angestellter> m_Unterstellte = new List<Angestellter>();
        //Methoden
        public void setName(string s) {
            m_Name = s;
        }
        public void AddUnterstellt(Angestellter a) {
            m_Unterstellte.Add(a);
        }

    }
}
