﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AufgabeB {
    public class Angestellter {
        //Membervariablen
        private string m_Name;
        //Konstruktoren
        public Angestellter(string s) {
            setNamen(s);
        }
        public Angestellter(string s, Boss b) {
            setNamen(s);
            setBoss(b);
        }
        //Methoden
        public void setNamen(string s) {
            m_Name = s;
        }
        public void setBoss(Boss b) {
            b.AddUnterstellt(this);
        }

    }
}
