﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonenAppV2.OhneProperties
{
    public class Person
    {
        //Klassenvariablen (alle Objekte der Klasse teilen sich diese)
        private const double MINSALAER = 0;
        private const double MAXSALAER = 99999.95;
        private const int MINENTRYYEAR = 1975;
        //Memebervariablen (jedes Objekt hat seine eigene Variable)
        private int m_PersNr = 0;
        private string m_Anrede = "";
        private string m_Name = "";
        private string m_Vorname = "";
        private string m_Plz = "";
        private string m_Ort = "";
        private int m_Eintrittsjahr = 0;
        private double m_Salaer = 0.00;
        private double m_Pensum = 0.00;
        //Konstruktoren
        public Person() {
            setPersNr(-1);
            setAnrede("Frau");
            setName("Neue Person");
            setVorname("");
            setPlz("6000");
            setOrt("Luzern");
            setEintrittsjahr(DateTime.Now.Year);
            setSalaer(5000.00);
            setPensum(100.00);
        }
        public Person(int persnr) {
            setPersNr(persnr);
        }
        public Person(int persnr, string anrede, string name, string vornname) {
            setPersNr(persnr);
            setAnrede(anrede);
            setName(name);
            setVorname(vornname);
        }
        public Person(int persnr, string name, string vornname, int eintrittsjahr) {
            setPersNr(persnr);
            setName(name);
            setVorname(vornname);
            setEintrittsjahr(eintrittsjahr);
        }
        //Membermethoden (gehören zum Objekt und verwenden jeweils die eigenen Membervariablen)
        public int getPersNr() {
            return m_PersNr;
        }
        private void setPersNr(int value) { 
            m_PersNr = value;
        }
        public string getAnrede() {
            return m_Anrede;
        }
        private void setAnrede(string value) {
            m_Anrede = value;
        }
        public string getName() {
            return m_Name;
        }
        private void setName(string value) {
            m_Name = value;
        }
        public string getVorname() {
            return m_Vorname;
        }
        private void setVorname(string value) {
            m_Vorname = value;
        }
        public string getPlz() {
            return m_Plz;
        }
        private void setPlz(string value) {
            m_Plz = value;
        }
        public string getOrt() {
            return m_Ort;
        }
        private void setOrt(string value) {
            m_Ort = value;
        }
        public int getEintrittsjahr() {
            return m_Eintrittsjahr;
        }
        public void setEintrittsjahr(int value) {
            if (value < MINENTRYYEAR) {
                value = MINENTRYYEAR;
                MessageBox.Show("Der Minimalwert des Eintrittsjahres wurde unterschritten",
                                "Eingabefehler", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (value > DateTime.Now.Year) {
                value = DateTime.Now.Year;
                MessageBox.Show("Das Eintrittsjahr kann das aktuelle Jahr nicht überschreiten",
                                "Eingabefehler", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            m_Eintrittsjahr = value;
        }

        public double getSalaer() {
            return m_Salaer;
        }
        public void setSalaer(double value) {
            if (value < MINSALAER) {
                value = MINSALAER;
                MessageBox.Show("Der Minimalwert des Salärs wurde unterschritten", "Eingabefehler",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (value > MAXSALAER) {
                value = MAXSALAER;
                MessageBox.Show("Der Maximalwert des Salärs wurde überschritten", "Eingabefehler",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            m_Salaer = value;
        }
        public double getPensum() {
            return m_Pensum;
        }
        public void setPensum(double value) {
            m_Pensum = value;
        }
    }
}
