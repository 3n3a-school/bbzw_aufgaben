﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonenAppV2.OhneProperties
{
    public partial class frmNeu : Form
    {
        private Person m_NeuePerson = null;
        public frmNeu()
        {
            InitializeComponent();
        }
        public Person getNeuePerson() {
            return m_NeuePerson;
        }

        private void OnSave(object sender, EventArgs e)
        {
            m_NeuePerson = new Person();
            m_NeuePerson.setName(txtNamen.Text);
            m_NeuePerson.setVorname(txtVornamen.Text);
            this.DialogResult = DialogResult.OK;
        }

        private void OnCancel(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
