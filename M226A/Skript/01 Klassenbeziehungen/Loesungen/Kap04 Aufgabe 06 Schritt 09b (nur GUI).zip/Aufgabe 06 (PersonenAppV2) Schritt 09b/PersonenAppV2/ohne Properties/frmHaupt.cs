﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace PersonenAppV2.OhneProperties {
    public partial class frmHaupt : Form {
        //Membervariablen
        private List<Person> m_Personen = new List<Person>();  //Ein Array, welches die Adressen der Personenobjekte kennt
        private int m_Position;  // die ArrayIndexposition der Person die auf dem Formular dargestelt wird 

        /// <summary>
        /// Konstruktor
        /// </summary>
        public frmHaupt() { 
            InitializeComponent();
        }

        /// <summary>
        /// Ereignis das ausgeführt wird, wenn das Formular auf dem Bildschirm angezeigt wird
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnFormLoad(object sender, EventArgs e){
            for(int i = 1; i <= 3; i++){
                Person p = new Person();
                p.setName("Neue Person (" + Convert.ToString(i) + ")");
                m_Personen.Add(p);
            }
            m_Position = 1; 	//Das erste Personenobjekt soll visualisiert werden
            FillForm();
        }

        /// <summary>
        /// Methode welche die via Membervariable m_Position indexierte Person auf dem Formular anzeigt
        /// </summary>
        private void FillForm() {
            if (m_Personen.Count == 0)
            {
                txtNavigation.Text = "0/0";
                return;
            }
            txtNavigation.Text = Convert.ToString(m_Position) + "/" + Convert.ToString(m_Personen.Count);
            Person p = m_Personen[m_Position - 1];
            txtPersNr.Text = Convert.ToString(p.getPersNr());
            txtNamen.Text = p.getName();
            txtVornamen.Text = p.getVorname();
            txtPLZ.Text = p.getPlz();
            txtOrt.Text = p.getOrt();
            txtEintrittsjahr.Text = p.getEintrittsjahr().ToString();
            txtSalaer.Text = p.getSalaer().ToString();
            txtPensum.Text = p.getPensum().ToString();
        }
        /// <summary>
        /// Ereignis das ausgeführt wird, wenn der User auf "|<--" klickt
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnFirst(object sender, EventArgs e) {
            m_Position = 1;
            FillForm();
        }
        /// <summary>
        /// /Ereignis das ausgeführt wird, wenn der User auf "<--" klickt
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnPrevious(object sender, EventArgs e) {
            if (m_Position > 1) {
                m_Position--;
                FillForm();
            }
        }
        /// <summary>
        /// Ereignis das ausgeführt wird, wenn der User auf "-->" klickt
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnNext(object sender, EventArgs e)  {
            if (m_Position < m_Personen.Count) {
                m_Position++;
                FillForm();
            }
        }
        /// <summary>
        /// Ereignis das ausgeführt wird, wenn der User auf "-->|" klickt
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnLast(object sender, EventArgs e) {
            if (m_Personen.Count > 0) {
                m_Position = m_Personen.Count;
                FillForm();
            }
        }
        /// <summary>
        /// Ereignis das ausgeführt wird, wenn der User auf "Änderungen speichern" klickt
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnSave(object sender, EventArgs e) {
            Person p = m_Personen[m_Position - 1];
            p.setName(txtNamen.Text);
            p.setVorname(txtVornamen.Text);
            p.setPlz(txtPLZ.Text);
            p.setOrt(txtOrt.Text);
            p.setEintrittsjahr(Convert.ToInt32(txtEintrittsjahr.Text));
            p.setSalaer(Convert.ToDouble(txtSalaer.Text));
            p.setPensum(Convert.ToDouble(txtPensum.Text));
        }
        /// <summary>
        /// Ereignis das ausgeführt wird, wenn der User auf "Änderungen verwerfen" klickt
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnAbort(object sender, EventArgs e) {
            FillForm();
        }

        private void OnDelete(object sender, EventArgs e)
        {
            //Falls bereits vor dem Löschen keine Person mehr vorhanden ist
            if (m_Personen.Count == 0)
                return;
            //Löschvorgang durchführen
            m_Personen.RemoveAt(m_Position - 1);  //-1 weil das Array bei 0 beginnt
            //
            if (m_Personen.Count == 0)
            {
                txtNavigation.Text = "0/0";
                txtPersNr.Text = "";
                txtNamen.Text = "";
                txtVornamen.Text = "";
                txtPLZ.Text = "";
                txtOrt.Text = "";
                txtEintrittsjahr.Text = "";
                txtSalaer.Text = "";
                txtPensum.Text = "";
                panel3.Enabled = false;
                return;
            }
            //Falls die letze Person des Arrays gelöscht wurde
            if (m_Position - 1 == m_Personen.Count)
                m_Position--;
            FillForm();
        }

        private void OnNeuePersonErfassen(object sender, EventArgs e)
        {
            frmNeu f = new frmNeu();
            f.ShowDialog();
        }
    }
}
