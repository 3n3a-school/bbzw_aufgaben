﻿namespace PersonenAppV2.OhneProperties
{
    partial class frmNeu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnAbbrechen = new System.Windows.Forms.Button();
            this.btnSpeichern = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtVornamen = new System.Windows.Forms.TextBox();
            this.lblVornamen = new System.Windows.Forms.Label();
            this.txtNamen = new System.Windows.Forms.TextBox();
            this.lblNamen = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnAbbrechen);
            this.panel1.Controls.Add(this.btnSpeichern);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 81);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(417, 72);
            this.panel1.TabIndex = 2;
            // 
            // btnAbbrechen
            // 
            this.btnAbbrechen.Location = new System.Drawing.Point(100, 17);
            this.btnAbbrechen.Name = "btnAbbrechen";
            this.btnAbbrechen.Size = new System.Drawing.Size(127, 32);
            this.btnAbbrechen.TabIndex = 0;
            this.btnAbbrechen.Text = "Abbrechen";
            this.btnAbbrechen.UseVisualStyleBackColor = true;
            this.btnAbbrechen.Click += new System.EventHandler(this.OnCancel);
            // 
            // btnSpeichern
            // 
            this.btnSpeichern.Location = new System.Drawing.Point(234, 17);
            this.btnSpeichern.Name = "btnSpeichern";
            this.btnSpeichern.Size = new System.Drawing.Size(139, 32);
            this.btnSpeichern.TabIndex = 0;
            this.btnSpeichern.Text = "Speichern";
            this.btnSpeichern.UseVisualStyleBackColor = true;
            this.btnSpeichern.Click += new System.EventHandler(this.OnSave);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txtVornamen);
            this.panel2.Controls.Add(this.lblVornamen);
            this.panel2.Controls.Add(this.txtNamen);
            this.panel2.Controls.Add(this.lblNamen);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(417, 81);
            this.panel2.TabIndex = 4;
            // 
            // txtVornamen
            // 
            this.txtVornamen.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtVornamen.Location = new System.Drawing.Point(100, 45);
            this.txtVornamen.Margin = new System.Windows.Forms.Padding(4);
            this.txtVornamen.Name = "txtVornamen";
            this.txtVornamen.Size = new System.Drawing.Size(273, 22);
            this.txtVornamen.TabIndex = 9;
            // 
            // lblVornamen
            // 
            this.lblVornamen.AutoSize = true;
            this.lblVornamen.Location = new System.Drawing.Point(15, 48);
            this.lblVornamen.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblVornamen.Name = "lblVornamen";
            this.lblVornamen.Size = new System.Drawing.Size(77, 17);
            this.lblVornamen.TabIndex = 8;
            this.lblVornamen.Text = "Vornamen:";
            // 
            // txtNamen
            // 
            this.txtNamen.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNamen.Location = new System.Drawing.Point(100, 13);
            this.txtNamen.Margin = new System.Windows.Forms.Padding(4);
            this.txtNamen.Name = "txtNamen";
            this.txtNamen.Size = new System.Drawing.Size(273, 22);
            this.txtNamen.TabIndex = 7;
            // 
            // lblNamen
            // 
            this.lblNamen.AutoSize = true;
            this.lblNamen.Location = new System.Drawing.Point(15, 16);
            this.lblNamen.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNamen.Name = "lblNamen";
            this.lblNamen.Size = new System.Drawing.Size(57, 17);
            this.lblNamen.TabIndex = 6;
            this.lblNamen.Text = "Namen:";
            // 
            // frmNeu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(417, 153);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(435, 200);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(435, 200);
            this.Name = "frmNeu";
            this.Text = "Neue Person erfassen";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnAbbrechen;
        private System.Windows.Forms.Button btnSpeichern;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtVornamen;
        private System.Windows.Forms.Label lblVornamen;
        private System.Windows.Forms.TextBox txtNamen;
        private System.Windows.Forms.Label lblNamen;
    }
}