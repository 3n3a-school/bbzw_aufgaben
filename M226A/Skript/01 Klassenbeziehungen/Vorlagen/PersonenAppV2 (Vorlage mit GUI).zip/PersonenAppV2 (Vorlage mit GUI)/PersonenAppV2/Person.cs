﻿using System;
using System.Windows.Forms;

namespace PersonenAppV2
{
    public class Person
    {
        

    }
}
