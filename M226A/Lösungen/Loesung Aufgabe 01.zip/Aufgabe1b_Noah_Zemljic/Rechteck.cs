﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Block_1
{
    public class Rechteck
    {
        private double _seiteA, _seiteB;

        public Rechteck() {
            setSeiteA(0);
            setSeiteB(0);
        }
        public Rechteck(double sA, double sB)
        {
            setSeiteA(sA);
            setSeiteB(sB);
        }

        public double getSeiteA() {
            return _seiteA;
        }
        public double getSeiteB() {
            return _seiteA;
        }
        public void setSeiteA(double a) {
            _seiteA = a;
        }
        public void setSeiteB(double b) {
            _seiteB = b;
        }

        public static double calcFlaeche(double a, double b) {
            return a*b;
        }

        public double getFlaeche() {
            return _seiteA * _seiteB;
        }
        

    }
}
