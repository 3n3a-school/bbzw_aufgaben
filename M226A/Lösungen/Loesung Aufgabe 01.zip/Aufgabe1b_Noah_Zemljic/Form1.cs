﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Block_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
       

       private void btnBerechneDynamisch_Click(object sender, EventArgs e)
        {
            double sA = Convert.ToDouble(tbxSeiteA.Text);
            double sB = Convert.ToDouble(tbxSeiteB.Text);
            Rechteck r1 = new Rechteck(sA, sB);
            double flaeche = r1.getFlaeche();
            tbxFlaeche.Text = flaeche.ToString();

       }

       private void btnBerechneStatisch_Click(object sender, EventArgs e)
        {
            double sA = Convert.ToDouble(tbxSeiteA.Text);
            double sB = Convert.ToDouble(tbxSeiteB.Text);
            double flaeche =Rechteck.calcFlaeche(sA, sB);
            tbxFlaeche.Text = flaeche.ToString();
        }
    }
}
