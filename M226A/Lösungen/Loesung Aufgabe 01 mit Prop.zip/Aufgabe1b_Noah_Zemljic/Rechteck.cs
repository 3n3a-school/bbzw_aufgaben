﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Block_1
{
    public class Rechteck
    {
        private double _seiteA;
        public Rechteck(double sa, double sb)
        {
            SeiteA = sa;
            SeiteB = sb;
        }
        public double SeiteA {
            get { return _seiteA; }
            set { _seiteA = value; } 
        }
        public double SeiteB { get; set; }  //prop <tab> <tab>
        public double Flaeche {
            get return SeiteA*SeiteB;} 
        }

        public static double calcFlaeche(double a, double b) {
            return a*b;
        }

        

    }
}
